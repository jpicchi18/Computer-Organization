/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_481(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_336()
{
    return 2425378989U;
}

unsigned getval_447()
{
    return 3351742792U;
}

unsigned addval_475(unsigned x)
{
    return x + 2421715346U;
}

void setval_135(unsigned *p)
{
    *p = 2428995912U;
}

unsigned addval_470(unsigned x)
{
    return x + 2425394264U;
}

unsigned addval_388(unsigned x)
{
    return x + 2496104776U;
}

unsigned addval_304(unsigned x)
{
    return x + 2425393272U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_263()
{
    return 3375943305U;
}

void setval_340(unsigned *p)
{
    *p = 3674260105U;
}

unsigned getval_236()
{
    return 2425537161U;
}

unsigned addval_159(unsigned x)
{
    return x + 2425409161U;
}

unsigned addval_275(unsigned x)
{
    return x + 3682913961U;
}

void setval_260(unsigned *p)
{
    *p = 3252717896U;
}

unsigned getval_300()
{
    return 3374367369U;
}

void setval_427(unsigned *p)
{
    *p = 3526938248U;
}

unsigned getval_280()
{
    return 3529556617U;
}

unsigned getval_450()
{
    return 3375940237U;
}

void setval_129(unsigned *p)
{
    *p = 3507091075U;
}

void setval_451(unsigned *p)
{
    *p = 3515480317U;
}

void setval_215(unsigned *p)
{
    *p = 2430634304U;
}

void setval_120(unsigned *p)
{
    *p = 3281047049U;
}

void setval_165(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_111()
{
    return 3353381192U;
}

unsigned getval_283()
{
    return 3252717896U;
}

unsigned getval_383()
{
    return 3676361089U;
}

unsigned addval_407(unsigned x)
{
    return x + 3285109215U;
}

unsigned getval_490()
{
    return 3222851977U;
}

unsigned addval_113(unsigned x)
{
    return x + 3373846921U;
}

void setval_434(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_161(unsigned x)
{
    return x + 3268315620U;
}

void setval_257(unsigned *p)
{
    *p = 3525366169U;
}

unsigned addval_293(unsigned x)
{
    return x + 3526938313U;
}

unsigned addval_373(unsigned x)
{
    return x + 3286272456U;
}

unsigned getval_412()
{
    return 2425406089U;
}

unsigned getval_318()
{
    return 3758704863U;
}

void setval_456(unsigned *p)
{
    *p = 3224945291U;
}

unsigned addval_327(unsigned x)
{
    return x + 3677933961U;
}

unsigned addval_233(unsigned x)
{
    return x + 2425409921U;
}

unsigned getval_173()
{
    return 3683959433U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
